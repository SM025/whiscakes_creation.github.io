<?php
    $image = $_GET['image'];
    
    echo"
        <a href='../application.php' class='lightbox' id='img1'>
            <img src='../images/reseller_id/$image'  alt=''>
        </a> 
    ";
?>